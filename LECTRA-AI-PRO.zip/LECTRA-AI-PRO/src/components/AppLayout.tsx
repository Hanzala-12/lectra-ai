import { Link, Outlet, useLocation, Navigate } from 'react-router-dom';
import { LayoutDashboard, UploadCloud, Library, HelpCircle, LineChart, MessageSquare, LogOut, GraduationCap, Sun, Moon } from 'lucide-react';
import { useDarkMode } from '../hooks/useDarkMode';

const NAV = [
  { path: '/app/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/app/upload',    icon: UploadCloud,     label: 'Upload' },
  { path: '/app/library',   icon: Library,         label: 'Library' },
  { path: '/app/quiz',      icon: HelpCircle,      label: 'Quizzes' },
  { path: '/app/analytics', icon: LineChart,        label: 'Analytics' },
  { path: '/app/chat',      icon: MessageSquare,   label: 'AI Chat' },
];

export function AppLayout() {
  const location = useLocation();
  const { dark, toggle } = useDarkMode();

  return (
    <div className="flex flex-col md:flex-row max-w-[1400px] mx-auto w-full px-4 md:px-6">
      {/* Sidebar */}
      <aside className="w-56 shrink-0 hidden md:flex flex-col py-10 pr-6 border-r border-border min-h-[calc(100vh-6rem)] sticky top-24 h-fit">
        <Link to="/" className="flex items-center gap-2 mb-8 group">
          <div className="w-7 h-7 rounded-lg bg-accent/10 flex items-center justify-center border border-accent/20 group-hover:bg-accent/20 transition-colors">
            <GraduationCap className="w-3.5 h-3.5 text-accent2" />
          </div>
          <span className="font-display text-base font-bold">LECTRA-AI</span>
        </Link>

        <nav className="flex flex-col gap-1 flex-1">
          {NAV.map(({ path, icon: Icon, label }) => {
            const active = location.pathname === path || (path === '/app/dashboard' && location.pathname === '/app');
            return (
              <Link key={path} to={path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
                  active ? 'bg-accent text-white shadow-sm' : 'text-muted hover:bg-surface hover:text-text'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />{label}
              </Link>
            );
          })}
        </nav>

        <div className="border-t border-border pt-4 mt-4 flex flex-col gap-2">
          <button onClick={toggle} className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted hover:bg-surface hover:text-text transition-colors">
            {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {dark ? 'Light mode' : 'Dark mode'}
          </button>
          <Link to="/login" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted hover:bg-red-light hover:text-red transition-colors">
            <LogOut className="w-4 h-4" />Sign Out
          </Link>
          <div className="px-3 pt-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-accent text-white flex items-center justify-center text-xs font-bold">HR</div>
              <div className="min-w-0">
                <div className="text-xs font-medium truncate">Hassan Raza</div>
                <div className="text-[10px] text-muted font-mono truncate">hr@nuces.edu.pk</div>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Nav */}
      <div className="md:hidden w-full overflow-x-auto flex gap-2 py-3 border-b border-border sticky top-16 bg-bg z-40">
        {NAV.map(({ path, icon: Icon, label }) => {
          const active = location.pathname === path;
          return (
            <Link key={path} to={path}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 ${active ? 'bg-accent text-white' : 'bg-surface text-muted'}`}
            >
              <Icon className="w-3.5 h-3.5" />{label}
            </Link>
          );
        })}
      </div>

      <main className="flex-1 min-w-0 py-4 md:pl-8 page-enter">
        <Outlet />
      </main>
    </div>
  );
}
