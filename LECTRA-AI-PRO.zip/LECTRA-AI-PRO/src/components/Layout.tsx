import { Link, Outlet, useLocation } from 'react-router-dom';
import { Menu, X, GraduationCap, Sun, Moon } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useDarkMode } from '../hooks/useDarkMode';

export function Layout() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { dark, toggle } = useDarkMode();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); }, [location]);

  return (
    <div className="min-h-screen flex flex-col">
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-bg/85 backdrop-blur-md border-b border-border py-3' : 'bg-transparent py-5'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center border border-accent/20 group-hover:bg-accent/20 transition-colors">
              <GraduationCap className="w-4 h-4 text-accent2" />
            </div>
            <span className="font-display text-xl tracking-tight font-bold">LECTRA-AI</span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <Link to="/features" className="text-sm font-medium text-muted hover:text-accent transition-colors">Features</Link>
            <a href="/#how-it-works" className="text-sm font-medium text-muted hover:text-accent transition-colors">How It Works</a>
            <Link to="/about" className="text-sm font-medium text-muted hover:text-accent transition-colors">About</Link>
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button onClick={toggle} className="p-2 rounded-lg text-muted hover:text-text hover:bg-surface2 transition-colors" aria-label="Toggle dark mode">
              {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <Link to="/login" className="text-sm font-medium text-muted hover:text-accent transition-colors px-3 py-2">Sign In</Link>
            <Link to="/app/upload" className="text-sm font-bold bg-accent hover:bg-accent2 text-white px-5 py-2.5 rounded-lg transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5">Try Free</Link>
          </div>

          <div className="md:hidden flex items-center gap-2">
            <button onClick={toggle} className="p-2 text-muted hover:text-text">
              {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button className="p-2 text-muted hover:text-text" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-surface border-b border-border p-6 flex flex-col gap-4 shadow-xl">
            <Link to="/features" className="text-base font-medium hover:text-accent transition-colors">Features</Link>
            <a href="/#how-it-works" className="text-base font-medium hover:text-accent transition-colors">How It Works</a>
            <Link to="/about" className="text-base font-medium hover:text-accent transition-colors">About</Link>
            <div className="h-px bg-border my-1" />
            <Link to="/login" className="text-center font-medium text-text px-5 py-3 rounded-xl border border-border">Sign In</Link>
            <Link to="/app/upload" className="text-center font-bold bg-accent text-white px-5 py-3 rounded-xl">Try Free</Link>
          </div>
        )}
      </header>

      <main className="flex-1 pt-24"><Outlet /></main>

      <footer className="bg-text text-white/40 mt-24">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-12 mb-16">
            <div className="col-span-1 md:col-span-2">
              <Link to="/" className="flex items-center gap-2 mb-4">
                <div className="w-6 h-6 rounded bg-white/10 flex items-center justify-center border border-white/20">
                  <GraduationCap className="w-3 h-3 text-white" />
                </div>
                <span className="font-display text-lg font-bold text-white">LECTRA-AI</span>
              </Link>
              <p className="text-sm text-white/60 mb-6 max-w-xs">AI-powered lecture intelligence platform that transforms raw classroom recordings into personalized, interactive learning resources.</p>
              <p className="text-xs font-mono text-white/40 uppercase tracking-widest">NUCES Department of Artificial Intelligence · CFD 2026</p>
            </div>
            <div>
              <h4 className="font-mono text-xs uppercase tracking-widest text-white/60 mb-6">Product</h4>
              <ul className="flex flex-col gap-3 text-sm">
                {[['Upload','/app/upload'],['Library','/app/library'],['Quiz','/app/quiz'],['Analytics','/app/analytics'],['AI Chat','/app/chat']].map(([label,path])=>(
                  <li key={path}><Link to={path} className="hover:text-white transition-colors">{label}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-mono text-xs uppercase tracking-widest text-white/60 mb-6">Features</h4>
              <ul className="flex flex-col gap-3 text-sm">
                {[['All Modules','/features'],['Noise Removal','/features'],['Smart Transcripts','/features'],['AI Explanations','/features'],['Urdu Support','/features']].map(([label,path])=>(
                  <li key={label}><Link to={path} className="hover:text-white transition-colors">{label}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-mono text-xs uppercase tracking-widest text-white/60 mb-6">Company</h4>
              <ul className="flex flex-col gap-3 text-sm">
                {[['About Us','/about'],['Privacy','/privacy'],['Terms','/terms'],['Use Cases','/use-cases']].map(([label,path])=>(
                  <li key={label}><Link to={path} className="hover:text-white transition-colors">{label}</Link></li>
                ))}
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/10 gap-4">
            <p className="text-xs font-mono">© {new Date().getFullYear()} LECTRA-AI · Hassan Raza · M Hanzala Yaqoob · Muhammad Zohair Hassnain · NUCES CFD 2026</p>
            <p className="text-xs font-mono text-white/30">Built with Whisper · pyannote · LangChain · FAISS</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
