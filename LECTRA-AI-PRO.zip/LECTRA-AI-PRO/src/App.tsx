import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { AppLayout } from './components/AppLayout';
import { Home } from './pages/Home';
import { App as DemoApp } from './pages/App';
import { Features } from './pages/Features';
import { Docs } from './pages/Docs';
import { About } from './pages/About';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Dashboard } from './pages/Dashboard';
import { Library } from './pages/Library';
import { Quiz } from './pages/Quiz';
import { Analytics } from './pages/Analytics';
import { Chat } from './pages/Chat';
import { NotFound } from './pages/NotFound';
import { Privacy } from './pages/Privacy';
import { Terms } from './pages/Terms';
import { UseCases } from './pages/UseCases';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />

          <Route path="app" element={<AppLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="upload" element={<DemoApp />} />
            <Route path="library" element={<Library />} />
            <Route path="quiz" element={<Quiz />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="chat" element={<Chat />} />
          </Route>

          <Route path="features" element={<Features />} />
          <Route path="docs" element={<Docs />} />
          <Route path="about" element={<About />} />
          <Route path="login" element={<Login />} />
          <Route path="signup" element={<Signup />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="terms" element={<Terms />} />
          <Route path="use-cases" element={<UseCases />} />

          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
