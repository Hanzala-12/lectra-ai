import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Play, FileText, HelpCircle, UploadCloud, Grid3X3, List, Clock, Users } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const SUBJECTS = ['All', 'CS401', 'CS311', 'CS201', 'CS101'];

const LECTURES = [
  { id: 1, title: 'Machine Learning — Lecture 5: Neural Networks', course: 'CS401', date: 'Oct 15', dur: '1:12:00', speakers: 4, score: 84, done: true },
  { id: 2, title: 'Database Systems — Normalization & 3NF', course: 'CS311', date: 'Oct 13', dur: '0:58:00', speakers: 2, score: 72, done: false },
  { id: 3, title: 'Data Structures — AVL Trees & Rotations', course: 'CS201', date: 'Oct 11', dur: '1:05:00', speakers: 2, score: 91, done: true },
  { id: 4, title: 'Machine Learning — Lecture 4: Backpropagation', course: 'CS401', date: 'Oct 9', dur: '1:08:00', speakers: 3, score: 55, done: true },
  { id: 5, title: 'Database Systems — SQL Joins Deep Dive', course: 'CS311', date: 'Oct 7', dur: '1:01:00', speakers: 2, score: 58, done: false },
  { id: 6, title: 'Programming Fundamentals — Recursion', course: 'CS101', date: 'Oct 5', dur: '0:52:00', speakers: 1, score: 95, done: true },
];

function MiniWave({ seed }: { seed: number }) {
  const bars = 30;
  return (
    <div className="flex items-end gap-[2px] h-full w-full px-3 py-2">
      {Array.from({ length: bars }).map((_, i) => {
        const h = Math.max(15, Math.abs(Math.sin(i * 0.6 + seed) * 80 + Math.sin(i * 1.3 + seed * 2) * 20));
        return <div key={i} className="flex-1 bg-accent/40 rounded-sm" style={{ height: `${h}%` }} />;
      })}
    </div>
  );
}

export function Library() {
  const [query, setQuery] = useState('');
  const [subject, setSubject] = useState('All');
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const filtered = LECTURES.filter(l =>
    (subject === 'All' || l.course === subject) &&
    l.title.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="py-8 page-enter">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl mb-1">Smart Lecture Library</h1>
          <p className="text-muted text-sm">{LECTURES.length} lectures · search by topic, date, or course</p>
        </div>
        <Link to="/app/upload" className="hidden sm:flex items-center gap-2 bg-accent hover:bg-accent2 text-white px-5 py-2.5 rounded-xl text-sm font-bold transition-all shadow-sm hover:-translate-y-0.5">
          <UploadCloud className="w-4 h-4" /> Upload New
        </Link>
      </div>

      {/* Search + filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted w-4 h-4" />
          <input value={query} onChange={e => setQuery(e.target.value)} type="text" placeholder="Search transcripts, notes, or topics..." className="w-full pl-11 pr-4 py-3 rounded-xl border border-border bg-surface focus:border-accent outline-none text-sm transition-colors" />
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-3 rounded-xl border border-border bg-surface hover:bg-surface2 transition-colors text-sm">
            <Filter className="w-4 h-4" /> Filters
          </button>
          <button onClick={() => setView(v => v === 'grid' ? 'list' : 'grid')} className="p-3 rounded-xl border border-border bg-surface hover:bg-surface2 transition-colors">
            {view === 'grid' ? <List className="w-4 h-4" /> : <Grid3X3 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Subject pills */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        {SUBJECTS.map(s => (
          <button key={s} onClick={() => setSubject(s)}
            className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-mono font-medium transition-all ${subject === s ? 'bg-accent text-white' : 'bg-surface border border-border text-muted hover:border-border2'}`}>
            {s}
          </button>
        ))}
      </div>

      {/* Results */}
      {filtered.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-14 h-14 rounded-2xl bg-surface2 flex items-center justify-center mx-auto mb-4"><Search className="w-7 h-7 text-muted" /></div>
          <p className="font-medium mb-2">No lectures found</p>
          <p className="text-sm text-muted">Try a different search term or subject filter.</p>
        </div>
      ) : view === 'grid' ? (
        <div className="grid md:grid-cols-3 gap-5">
          {filtered.map((l, i) => (
            <Reveal key={l.id} delay={i * 50}>
              <div className="bg-surface border border-border rounded-xl overflow-hidden card-lift hover:border-accent2 cursor-pointer group">
                <div className="h-28 bg-surface2 relative overflow-hidden">
                  <MiniWave seed={l.id * 3} />
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-accent/10">
                    <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center shadow-lg"><Play className="w-4 h-4 text-white ml-0.5" /></div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-text/70 text-white text-[10px] font-mono px-2 py-0.5 rounded">{l.dur}</div>
                  <div className="absolute top-2 left-2">
                    <span className="text-[10px] font-mono uppercase tracking-widest bg-accent-light text-accent px-2 py-0.5 rounded border border-accent/20">{l.course}</span>
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-sm mb-1 line-clamp-2 leading-snug">{l.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-muted font-mono mb-4">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{l.date}</span>
                    <span className="flex items-center gap-1"><Users className="w-3 h-3" />{l.speakers}</span>
                    {l.done && <span className="flex items-center gap-1 text-teal">{l.score}% avg</span>}
                  </div>
                  <div className="flex items-center gap-3 pt-3 border-t border-border">
                    <Link to="/app/chat" className="flex items-center gap-1 text-xs font-medium text-muted hover:text-accent transition-colors"><FileText className="w-3.5 h-3.5" /> Transcript</Link>
                    <Link to="/app/quiz" className="flex items-center gap-1 text-xs font-medium text-muted hover:text-teal transition-colors"><HelpCircle className="w-3.5 h-3.5" /> Quiz</Link>
                    {!l.done && <span className="ml-auto text-[10px] font-mono bg-amber-light text-amber px-2 py-0.5 rounded border border-amber/20">DUE</span>}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((l, i) => (
            <Reveal key={l.id} delay={i * 40}>
              <div className="bg-surface border border-border rounded-xl p-4 card-lift flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-surface2 flex items-center justify-center shrink-0 overflow-hidden">
                  <MiniWave seed={l.id * 3} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate mb-1">{l.title}</div>
                  <div className="text-xs text-muted font-mono">{l.course} · {l.date} · {l.dur} · {l.speakers} speakers</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {l.done && <span className="text-[10px] font-mono text-teal">{l.score}%</span>}
                  <Link to="/app/quiz" className="text-xs text-muted hover:text-accent px-3 py-1.5 border border-border rounded-lg transition-colors">Quiz</Link>
                  <Link to="/app/chat" className="text-xs text-accent font-medium px-3 py-1.5 bg-accent-light border border-accent/20 rounded-lg hover:bg-accent hover:text-white transition-colors">View</Link>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      )}
    </div>
  );
}
