import { Link } from 'react-router-dom';
import { GraduationCap, Brain, Code2, ArrowRight } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const TEAM = [
  { name: 'Hassan Raza', role: 'Backend & AI Pipeline', desc: 'Leads the audio processing pipeline, Whisper integration, and FastAPI backend. Passionate about building AI systems that solve real problems.', initials: 'HR', color: 'bg-accent' },
  { name: 'M Hanzala Yaqoob', role: 'Frontend & UX', desc: 'Designs and builds the React frontend, user experience, and component library. Focused on making complex AI tools feel simple and intuitive.', initials: 'MH', color: 'bg-teal' },
  { name: 'Muhammad Zohair Hassnain', role: 'AI & RAG Systems', desc: 'Builds the RAG pipeline, vector database, and AI explanation generation. Works on multilingual NLP and LangChain integrations.', initials: 'MZ', color: 'bg-purple' },
];

const STACK = [
  { cat: 'Audio Processing', items: ['Whisper ASR (OpenAI)', 'pyannote.audio (diarization)', 'DeepFilterNet (noise removal)', 'librosa (analysis)'] },
  { cat: 'AI & NLP', items: ['LangChain', 'FAISS / ChromaDB (vector store)', 'OpenAI GPT-4 (explanations)', 'Custom multilingual prompts'] },
  { cat: 'Backend', items: ['FastAPI (Python)', 'PostgreSQL', 'Redis (job queue)', 'Docker + Nginx'] },
  { cat: 'Frontend', items: ['React 19 + TypeScript', 'Tailwind CSS v4', 'Vite', 'React Router v7'] },
];

export function About() {
  return (
    <div className="py-24">
      <div className="max-w-7xl mx-auto px-6">
        {/* Mission */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <Reveal>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent-light border border-accent/20 text-xs font-mono uppercase tracking-widest text-accent mb-6">
              <GraduationCap className="w-3.5 h-3.5" /> NUCES CFD · Final Year Project 2026
            </div>
            <h1 className="font-display text-5xl mb-6">We built the tool <em className="text-accent2 not-italic">we needed.</em></h1>
            <p className="text-xl text-muted leading-relaxed">
              LECTRA-AI was born out of a simple frustration: three CS students at NUCES spending more time rewinding noisy lecture recordings than actually studying. We decided to fix that.
            </p>
          </Reveal>
        </div>

        {/* Story */}
        <Reveal>
          <div className="bg-surface border border-border rounded-2xl p-10 mb-16 max-w-4xl mx-auto">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-accent-light flex items-center justify-center border border-accent/20">
                <Brain className="w-5 h-5 text-accent" />
              </div>
              <h2 className="font-display text-2xl">The story</h2>
            </div>
            <div className="space-y-4 text-muted leading-relaxed">
              <p>In Pakistan's engineering universities, lecture recordings are often the primary way students review material — especially for missed classes or exam prep. But the quality of these recordings is usually poor: background AC noise, overlapping student conversations, and cheap microphones make them hard to follow.</p>
              <p>We started by building a simple noise filter. Then we added transcription. Then we realized we could use those transcripts to generate AI explanations in Roman Urdu — the way our professors actually explain things in class, not the formal Urdu that textbooks use.</p>
              <p>LECTRA-AI is our Final Year Project for the Bachelor of Science in Artificial Intelligence at NUCES Chiniot-Faisalabad. It represents everything we've learned about audio processing, NLP, RAG systems, and building user-facing AI products.</p>
            </div>
          </div>
        </Reveal>

        {/* Team */}
        <div className="mb-20">
          <Reveal><h2 className="font-display text-3xl text-center mb-12">The team</h2></Reveal>
          <div className="grid md:grid-cols-3 gap-6">
            {TEAM.map((member, i) => (
              <Reveal key={member.name} delay={i * 100}>
                <div className="bg-surface border border-border rounded-2xl p-7 card-lift text-center">
                  <div className={`w-16 h-16 rounded-2xl ${member.color} text-white flex items-center justify-center text-xl font-bold mx-auto mb-5`}>{member.initials}</div>
                  <h3 className="font-bold text-lg mb-1">{member.name}</h3>
                  <div className="text-xs font-mono text-accent uppercase tracking-widest mb-4">{member.role}</div>
                  <p className="text-sm text-muted leading-relaxed">{member.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Tech stack */}
        <Reveal>
          <div className="mb-16">
            <div className="flex items-center gap-3 mb-8 justify-center">
              <Code2 className="w-5 h-5 text-muted" />
              <h2 className="font-display text-3xl">Tech stack</h2>
            </div>
            <div className="grid md:grid-cols-4 gap-5">
              {STACK.map(({ cat, items }) => (
                <div key={cat} className="bg-surface border border-border rounded-xl p-5">
                  <div className="text-[10px] font-mono uppercase tracking-widest text-muted mb-4">{cat}</div>
                  <ul className="space-y-2">
                    {items.map(item => (
                      <li key={item} className="text-xs flex items-start gap-2">
                        <span className="text-accent mt-0.5">›</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* CTA */}
        <Reveal>
          <div className="text-center">
            <h2 className="font-display text-3xl mb-4">Try what we built.</h2>
            <p className="text-muted mb-8">No signup required. Upload a lecture and see the full pipeline in action.</p>
            <Link to="/app/upload" className="inline-flex items-center gap-2 bg-accent hover:bg-accent2 text-white px-8 py-4 rounded-xl font-bold transition-all shadow-sm hover:-translate-y-0.5">
              Upload a Lecture <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
