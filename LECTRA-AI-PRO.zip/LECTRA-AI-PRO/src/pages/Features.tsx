import { Link } from 'react-router-dom';
import { FileAudio, BookOpen, Brain, Target, LineChart, Library, MessageSquare, Zap, Languages, Shield, ArrowRight } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const FEATURES = [
  {
    icon: FileAudio, color: 'text-accent', bg: 'bg-accent-light', border: 'border-accent/20',
    title: 'Noise Removal & Speaker Diarization',
    desc: 'Our pipeline uses state-of-the-art noise suppression followed by pyannote.audio for speaker diarization. Each speaker gets a separate audio track and color-coded transcript segment. Works with up to 8 simultaneous speakers.',
    tags: ['pyannote.audio', 'DeepFilterNet', 'per-speaker audio'],
  },
  {
    icon: BookOpen, color: 'text-teal', bg: 'bg-teal-light', border: 'border-teal/20',
    title: 'Smart Transcription',
    desc: 'Powered by OpenAI Whisper fine-tuned on academic speech, our transcription delivers 95%+ accuracy with full timestamps. Every word is linked to its exact second in the audio — click any line to jump there.',
    tags: ['Whisper ASR', 'timestamped', 'SRT / VTT / JSON export'],
  },
  {
    icon: Brain, color: 'text-purple', bg: 'bg-purple-light', border: 'border-purple/20',
    title: 'AI Explanations',
    desc: 'Every topic detected in the lecture gets an AI-generated explanation at your chosen difficulty: Beginner (analogies and real-world examples), Intermediate (technical but accessible), or Advanced (academic-level detail). Available in English, Urdu, and Roman Urdu.',
    tags: ['3 difficulty levels', 'English · Urdu · Roman Urdu', 'LangChain'],
  },
  {
    icon: Target, color: 'text-amber', bg: 'bg-amber-light', border: 'border-amber/20',
    title: 'Quiz Generation',
    desc: 'Auto-generated MCQs and short-answer questions built directly from your lecture content. Questions are weighted toward topics the teacher emphasized most. Each question comes with a timestamped explanation from the actual lecture.',
    tags: ['MCQs + short answer', 'timed mode', 'immediate feedback'],
  },
  {
    icon: LineChart, color: 'text-red', bg: 'bg-red-light', border: 'border-red/20',
    title: 'Weakness Detection & Analytics',
    desc: 'After each quiz, our analytics engine identifies which topics you struggle with, tracks your improvement over time, and builds a heatmap of your performance across all lectures. The study plan adapts automatically.',
    tags: ['heatmap analysis', 'study plan', 'trend tracking'],
  },
  {
    icon: Library, color: 'text-accent2', bg: 'bg-accent-light', border: 'border-accent/20',
    title: 'Smart Lecture Library',
    desc: 'All your processed lectures in one place. Full-text search across every transcript instantly. Filter by course code, date, or performance score. List and grid views. Each lecture shows a waveform thumbnail, duration, and speaker count.',
    tags: ['full-text search', 'filter by course', 'waveform thumbnails'],
  },
  {
    icon: MessageSquare, color: 'text-teal', bg: 'bg-teal-light', border: 'border-teal/20',
    title: 'Lecture AI Chatbot (RAG)',
    desc: 'Ask anything about your lecture and get answers grounded in the actual content. The chatbot uses Retrieval-Augmented Generation (RAG) to pull the exact relevant transcript segments before answering — so you always know where the answer came from.',
    tags: ['RAG pipeline', 'citation timestamps', 'FAISS vector store'],
  },
  {
    icon: Languages, color: 'text-purple', bg: 'bg-purple-light', border: 'border-purple/20',
    title: 'Multilingual Support',
    desc: 'Built for Pakistani university students. Transcription is in English (as spoken), but explanations and chatbot responses are available in English, Urdu, and Roman Urdu. Switch languages mid-conversation — no restart needed.',
    tags: ['English', 'Urdu', 'Roman Urdu'],
  },
];

export function Features() {
  return (
    <div className="py-24">
      {/* Hero */}
      <div className="max-w-4xl mx-auto px-6 text-center mb-20">
        <Reveal>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent-light border border-accent/20 text-xs font-mono uppercase tracking-widest text-accent mb-6">
            <Zap className="w-3.5 h-3.5" /> Full Feature Breakdown
          </div>
          <h1 className="font-display text-5xl md:text-6xl mb-6">
            Every feature, <em className="text-accent2 not-italic">explained.</em>
          </h1>
          <p className="text-xl text-muted max-w-2xl mx-auto leading-relaxed">
            LECTRA-AI is not just a transcription tool. It's a complete learning pipeline from raw audio to exam-ready knowledge.
          </p>
        </Reveal>
      </div>

      {/* Feature cards */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {FEATURES.map(({ icon: Icon, color, bg, border, title, desc, tags }, i) => (
            <Reveal key={title} delay={(i % 2) * 80}>
              <div className="bg-surface border border-border rounded-2xl p-8 card-lift hover:border-accent2">
                <div className={`w-12 h-12 rounded-xl ${bg} border ${border} flex items-center justify-center mb-5`}>
                  <Icon className={`w-6 h-6 ${color}`} />
                </div>
                <h3 className="text-xl font-bold mb-3">{title}</h3>
                <p className="text-muted leading-relaxed mb-5 text-sm">{desc}</p>
                <div className="flex flex-wrap gap-2">
                  {tags.map(t => (
                    <span key={t} className="text-[10px] font-mono bg-bg border border-border px-2.5 py-1 rounded-full text-muted">{t}</span>
                  ))}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Security note */}
        <Reveal>
          <div className="bg-surface2 border border-border rounded-2xl p-8 flex flex-col md:flex-row items-center gap-6 mb-16">
            <div className="w-14 h-14 rounded-2xl bg-teal-light border border-teal/20 flex items-center justify-center shrink-0">
              <Shield className="w-7 h-7 text-teal" />
            </div>
            <div className="flex-1 text-center md:text-left">
              <h3 className="font-bold text-lg mb-2">Your data stays yours</h3>
              <p className="text-muted text-sm leading-relaxed">Audio files are processed server-side and never used for model training. You can delete any lecture and all associated data at any time. We never sell or share your data.</p>
            </div>
            <Link to="/privacy" className="shrink-0 flex items-center gap-2 text-sm font-medium text-accent hover:underline">
              Read Privacy Policy <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </Reveal>

        {/* CTA */}
        <Reveal>
          <div className="text-center">
            <h2 className="font-display text-3xl mb-4">Ready to try it?</h2>
            <p className="text-muted mb-8">No signup required. Upload your first lecture and see results in minutes.</p>
            <Link to="/app/upload" className="inline-flex items-center gap-2 bg-accent hover:bg-accent2 text-white px-8 py-4 rounded-xl font-bold transition-all shadow-sm hover:-translate-y-0.5">
              Upload a Lecture <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
