import { Link } from 'react-router-dom';
import { BookOpen, ArrowRight, Terminal, Zap, Shield } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const SECTIONS = [
  { icon: Zap, title: 'Getting Started', desc: 'Upload your first lecture and get a transcript in minutes. No account required.', link: '/app/upload' },
  { icon: Terminal, title: 'API Reference', desc: 'Integrate LECTRA-AI into your own apps. REST API with JSON responses.', link: '#' },
  { icon: Shield, title: 'Privacy & Data', desc: 'How your data is stored, processed, and protected.', link: '/privacy' },
  { icon: BookOpen, title: 'Full Docs', desc: 'Complete documentation including advanced features and configuration options.', link: '#' },
];

export function Docs() {
  return (
    <div className="py-24 max-w-4xl mx-auto px-6">
      <Reveal>
        <h1 className="font-display text-5xl mb-4">Documentation</h1>
        <p className="text-xl text-muted mb-16">Everything you need to get the most out of LECTRA-AI.</p>
      </Reveal>
      <div className="grid md:grid-cols-2 gap-5">
        {SECTIONS.map(({ icon: Icon, title, desc, link }, i) => (
          <Reveal key={title} delay={i * 80}>
            <Link to={link} className="block bg-surface border border-border rounded-2xl p-7 card-lift hover:border-accent2 group">
              <div className="w-10 h-10 rounded-xl bg-accent-light border border-accent/20 flex items-center justify-center mb-5">
                <Icon className="w-5 h-5 text-accent" />
              </div>
              <h3 className="font-bold text-lg mb-2 group-hover:text-accent transition-colors">{title}</h3>
              <p className="text-sm text-muted mb-4">{desc}</p>
              <div className="flex items-center gap-1 text-xs font-mono text-accent">Read more <ArrowRight className="w-3 h-3" /></div>
            </Link>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
