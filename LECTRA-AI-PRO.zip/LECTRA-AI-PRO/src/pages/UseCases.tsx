import { Link } from 'react-router-dom';
import { Moon, Users, BookOpen, Globe, ArrowRight } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const CASES = [
  {
    icon: Moon,
    color: 'text-accent', bg: 'bg-accent-light', border: 'border-accent/20',
    persona: 'The Exam Crammer',
    scenario: 'It\'s 11PM the night before your finals. You have 5 unreviewed lecture recordings from the past month.',
    steps: [
      'Upload all 5 lectures in one batch',
      'Get transcripts and AI explanations in under 20 minutes total',
      'Take the auto-generated quiz for each lecture',
      'Focus your last hours on the topics you scored lowest on',
    ],
    result: 'What would have taken 8+ hours of re-watching takes 45 minutes of focused review.',
    cta: '/app/upload',
    ctaLabel: 'Upload Lectures Now',
  },
  {
    icon: BookOpen,
    color: 'text-teal', bg: 'bg-teal-light', border: 'border-teal/20',
    persona: 'The Note Taker',
    scenario: 'You want organized, searchable notes from every lecture without spending hours typing.',
    steps: [
      'Upload the recording right after class',
      'Get a timestamped, speaker-labeled transcript automatically',
      'Highlight key concepts from the AI explanation',
      'Export notes as a formatted PDF',
    ],
    result: 'Professional lecture notes in minutes. Searchable across all your courses in the library.',
    cta: '/app/library',
    ctaLabel: 'See Your Library',
  },
  {
    icon: Users,
    color: 'text-purple', bg: 'bg-purple-light', border: 'border-purple/20',
    persona: 'The Group Studier',
    scenario: 'Your study group wants to review a lecture together but nobody can agree on which parts to focus on.',
    steps: [
      'One person uploads the lecture',
      'Share the processed lecture link with the group',
      'Everyone takes the same quiz independently',
      'Compare scores to identify group-wide weak spots',
    ],
    result: 'The whole group studies the same material, objectively identifies gaps, and focuses on what actually matters.',
    cta: '/signup',
    ctaLabel: 'Create Free Account',
  },
  {
    icon: Globe,
    color: 'text-amber', bg: 'bg-amber-light', border: 'border-amber/20',
    persona: 'The Language Bridger',
    scenario: 'Your professor lectures in English but you understand complex concepts better in Roman Urdu.',
    steps: [
      'Upload the English lecture recording',
      'Get a full English transcript with speaker labels',
      'Switch AI explanations to Roman Urdu mode',
      'Ask the chatbot questions in Roman Urdu and get answers in kind',
    ],
    result: 'Every concept explained the way your brain actually processes it — no translation barrier.',
    cta: '/features',
    ctaLabel: 'See Multilingual Features',
  },
];

export function UseCases() {
  return (
    <div className="py-24">
      <div className="max-w-4xl mx-auto px-6 text-center mb-20">
        <Reveal>
          <h1 className="font-display text-5xl mb-6">Real ways students use <em className="text-accent2 not-italic">LECTRA-AI</em></h1>
          <p className="text-xl text-muted leading-relaxed">Four personas. Four workflows. All powered by the same upload.</p>
        </Reveal>
      </div>

      <div className="max-w-7xl mx-auto px-6 space-y-8">
        {CASES.map(({ icon: Icon, color, bg, border, persona, scenario, steps, result, cta, ctaLabel }, i) => (
          <Reveal key={persona} delay={i * 60}>
            <div className={`bg-surface border border-border rounded-2xl overflow-hidden grid md:grid-cols-[1fr_1.4fr] card-lift`}>
              <div className={`${bg.replace('bg-', 'bg-').replace('-light', '-light/30')} border-r border-border p-10`}>
                <div className={`w-12 h-12 ${bg} border ${border} rounded-2xl flex items-center justify-center mb-5`}>
                  <Icon className={`w-6 h-6 ${color}`} />
                </div>
                <div className={`text-xs font-mono uppercase tracking-widest ${color} mb-3`}>Use Case {i + 1}</div>
                <h3 className="font-display text-2xl mb-4">{persona}</h3>
                <p className="text-muted text-sm leading-relaxed italic">"{scenario}"</p>
              </div>
              <div className="p-10">
                <h4 className="text-xs font-mono uppercase tracking-widest text-muted mb-5">Workflow</h4>
                <ol className="space-y-3 mb-7">
                  {steps.map((step, si) => (
                    <li key={si} className="flex items-start gap-3 text-sm">
                      <span className={`w-5 h-5 rounded-full ${bg} border ${border} flex items-center justify-center text-[10px] font-bold ${color} shrink-0 mt-0.5`}>{si + 1}</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ol>
                <div className="bg-bg rounded-xl p-4 border border-border mb-6">
                  <div className="text-xs font-mono text-muted uppercase tracking-widest mb-1">Result</div>
                  <p className="text-sm leading-relaxed">{result}</p>
                </div>
                <Link to={cta} className={`inline-flex items-center gap-2 ${bg} border ${border} ${color} px-5 py-2.5 rounded-xl text-sm font-bold hover:opacity-80 transition-opacity`}>
                  {ctaLabel} <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
