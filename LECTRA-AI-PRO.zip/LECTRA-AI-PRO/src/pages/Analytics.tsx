import { useState } from 'react';
import { Download, TrendingUp, AlertTriangle, Trophy, Brain, Calendar } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const WEEKLY = [62, 70, 65, 78, 82, 88, 84];
const TOPICS = [
  { name: 'Linear Regression', score: 95, color: 'bg-teal' },
  { name: 'Neural Networks', score: 84, color: 'bg-accent2' },
  { name: 'Activation Functions', score: 78, color: 'bg-purple' },
  { name: 'Generalization', score: 72, color: 'bg-amber' },
  { name: 'SQL Joins', score: 58, color: 'bg-amber' },
  { name: 'Backpropagation', score: 55, color: 'bg-red' },
  { name: 'Gradient Descent', score: 42, color: 'bg-red' },
];

// Study streak calendar (last 35 days)
const STREAK_DATA = Array.from({ length: 35 }, (_, i) => {
  const v = Math.random();
  return v > 0.35 ? (v > 0.7 ? 'high' : 'mid') : 'none';
});

const HEATMAP_TOPICS = ['Linear Regression', 'Neural Networks', 'Backpropagation', 'Gradient Descent', 'SQL Joins'];
const HEATMAP_WEEKS = ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5'];
const HEATMAP_DATA: Record<string, Record<string, number>> = {
  'Linear Regression':  { 'Week 1': 90, 'Week 2': 85, 'Week 3': 95, 'Week 4': 100, 'Week 5': 92 },
  'Neural Networks':    { 'Week 1': 60, 'Week 2': 70, 'Week 3': 80, 'Week 4': 88, 'Week 5': 84 },
  'Backpropagation':   { 'Week 1': 40, 'Week 2': 45, 'Week 3': 50, 'Week 4': 60, 'Week 5': 55 },
  'Gradient Descent':  { 'Week 1': 30, 'Week 2': 35, 'Week 3': 38, 'Week 4': 42, 'Week 5': 42 },
  'SQL Joins':         { 'Week 1': 55, 'Week 2': 50, 'Week 3': 62, 'Week 4': 58, 'Week 5': 58 },
};

function heatColor(v: number) {
  if (v >= 80) return 'bg-teal text-teal-light/90';
  if (v >= 65) return 'bg-accent2/70 text-white';
  if (v >= 50) return 'bg-amber text-amber-light/90';
  return 'bg-red/80 text-red-light/90';
}

export function Analytics() {
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const maxW = Math.max(...WEEKLY);

  return (
    <div className="py-8 page-enter">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl mb-1">Learning Analytics</h1>
          <p className="text-muted text-sm">Track your performance across all lectures and topics.</p>
        </div>
        <button className="hidden sm:flex items-center gap-2 px-5 py-2.5 rounded-xl border border-border bg-surface text-sm font-medium hover:bg-surface2 transition-colors">
          <Download className="w-4 h-4" /> Export Report
        </button>
      </div>

      {/* Top stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { icon: TrendingUp, label: 'Overall Progress', value: '78%', sub: '+5% from last month', color: 'text-accent2', bg: 'text-accent2' },
          { icon: Trophy,     label: 'Best Topic',       value: '95%', sub: 'Linear Regression', color: 'text-teal', bg: 'text-teal' },
          { icon: AlertTriangle, label: 'Weakest Topic', value: '42%', sub: 'Gradient Descent',  color: 'text-red', bg: 'text-red' },
          { icon: Brain,      label: 'Quizzes Taken',    value: '24',  sub: 'across 6 lectures', color: 'text-purple', bg: 'text-purple' },
        ].map(({ icon: Icon, label, value, sub, color }, i) => (
          <Reveal key={label} delay={i * 60}>
            <div className="bg-surface border border-border rounded-xl p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono text-muted uppercase tracking-widest">{label}</span>
                <Icon className={`w-4 h-4 ${color}`} />
              </div>
              <div className={`font-display text-3xl mb-1 ${color}`}>{value}</div>
              <div className="text-xs text-muted">{sub}</div>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-6">
        {/* Weekly score trend */}
        <Reveal>
          <div className="bg-surface border border-border rounded-xl p-6">
            <h3 className="font-bold mb-6 flex items-center gap-2"><TrendingUp className="w-4 h-4 text-accent" /> Weekly Score Trend</h3>
            <div className="flex items-end gap-3 h-44">
              {WEEKLY.map((score, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-2 group cursor-pointer" onMouseEnter={() => setHoveredBar(i)} onMouseLeave={() => setHoveredBar(null)}>
                  <div className="text-[10px] font-mono text-accent opacity-0 group-hover:opacity-100 transition-opacity">{score}%</div>
                  <div className="w-full rounded-t-lg transition-all duration-300 relative"
                    style={{
                      height: `${(score / maxW) * 140}px`,
                      background: hoveredBar === i ? 'var(--color-accent)' : score >= 80 ? 'var(--color-teal)' : score >= 65 ? 'var(--color-accent2)' : 'var(--color-amber)',
                      opacity: hoveredBar !== null && hoveredBar !== i ? 0.4 : 1,
                    }}
                  />
                  <div className="text-[9px] font-mono text-muted">{days[i]}</div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Topic performance bars */}
        <Reveal delay={80}>
          <div className="bg-surface border border-border rounded-xl p-6">
            <h3 className="font-bold mb-6 flex items-center gap-2"><Brain className="w-4 h-4 text-purple" /> Topic Performance</h3>
            <div className="space-y-4">
              {TOPICS.map(({ name, score, color }) => (
                <div key={name}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="truncate pr-2">{name}</span>
                    <span className={`font-mono font-bold text-xs ${score >= 80 ? 'text-teal' : score >= 60 ? 'text-amber' : 'text-red'}`}>{score}%</span>
                  </div>
                  <div className="w-full bg-surface2 rounded-full h-2 overflow-hidden">
                    <div className={`${color} h-2 rounded-full transition-all duration-700`} style={{ width: `${score}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>

      {/* Heatmap */}
      <Reveal>
        <div className="bg-surface border border-border rounded-xl p-6 mb-6">
          <h3 className="font-bold mb-6 flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber" /> Mistake Heatmap — by Topic & Week</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr>
                  <th className="text-left text-xs font-mono text-muted pb-3 pr-4 w-40">Topic</th>
                  {HEATMAP_WEEKS.map(w => <th key={w} className="text-xs font-mono text-muted pb-3 text-center px-2">{w}</th>)}
                </tr>
              </thead>
              <tbody>
                {HEATMAP_TOPICS.map(topic => (
                  <tr key={topic}>
                    <td className="text-xs py-1.5 pr-4 text-muted truncate max-w-[120px]">{topic}</td>
                    {HEATMAP_WEEKS.map(week => {
                      const v = HEATMAP_DATA[topic][week];
                      return (
                        <td key={week} className="py-1 px-1 text-center">
                          <div className={`${heatColor(v)} rounded-md py-1.5 text-[10px] font-mono font-bold cell-pop`} title={`${topic} · ${week}: ${v}%`}>{v}%</div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex items-center gap-6 mt-4 text-xs text-muted">
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded bg-teal" /> 80%+ (Strong)</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded bg-amber" /> 50–79% (Improving)</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded bg-red/80" /> &lt;50% (Needs work)</div>
          </div>
        </div>
      </Reveal>

      {/* Study streak */}
      <Reveal>
        <div className="bg-surface border border-border rounded-xl p-6">
          <h3 className="font-bold mb-2 flex items-center gap-2"><Calendar className="w-4 h-4 text-teal" /> Study Streak Calendar</h3>
          <p className="text-xs text-muted mb-5 font-mono">Last 35 days · Current streak: 6 days 🔥</p>
          <div className="flex gap-1.5 flex-wrap">
            {STREAK_DATA.map((level, i) => (
              <div key={i} className={`w-7 h-7 rounded-md cell-pop ${level === 'high' ? 'bg-teal' : level === 'mid' ? 'bg-accent2/50' : 'bg-surface2 border border-border'}`}
                style={{ animationDelay: `${i * 12}ms` }} title={`Day ${35 - i}`}
              />
            ))}
          </div>
          <div className="flex items-center gap-4 mt-4 text-xs text-muted">
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-surface2 border border-border" /> No activity</div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-accent2/50" /> Light study</div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-teal" /> Active study</div>
          </div>
        </div>
      </Reveal>
    </div>
  );
}
