import { Shield } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const SECTIONS = [
  {
    title: 'Data we collect',
    content: `When you upload a lecture, we temporarily store the audio file on our servers to process it. We also collect your email address and display name if you create an account. We do not collect any other personal information unless you explicitly provide it.`,
  },
  {
    title: 'How we process your audio',
    content: `Uploaded audio files are processed by our backend pipeline: noise suppression, speaker diarization, transcription, and AI explanation generation. Files are processed in isolated containers. Processed outputs (transcripts, explanations) are stored linked to your account for your library.`,
  },
  {
    title: 'Data retention',
    content: `Audio files are deleted from our servers within 24 hours of processing. Processed transcripts, explanations, and quiz results are retained as long as your account is active. You may delete any lecture and all associated data at any time from your library. Account data is deleted within 30 days of account deletion.`,
  },
  {
    title: 'We never sell your data',
    content: `We do not sell, trade, or share your personal data or lecture content with any third parties. Your lecture recordings are your intellectual property. We do not use your data to train AI models without your explicit opt-in consent.`,
  },
  {
    title: 'Third-party services',
    content: `Our platform uses OpenAI's API for AI explanation generation. Audio data is sent to OpenAI's servers only in the form of text transcripts — never raw audio. We comply with OpenAI's data usage policies. We also use standard cloud infrastructure providers (AWS / GCP) for hosting.`,
  },
  {
    title: 'Your rights',
    content: `You have the right to access all data we hold about you, request deletion of your account and all associated data, export your transcripts and quiz results at any time, and opt out of any analytics or feature-improvement data collection.`,
  },
  {
    title: 'Security',
    content: `All data is transmitted over HTTPS (TLS 1.3). Audio files and transcripts are stored with AES-256 encryption at rest. Account passwords are hashed using bcrypt. We conduct regular security audits.`,
  },
  {
    title: 'Contact',
    content: `For any privacy concerns, data access requests, or deletion requests, contact us at: privacy@lectra-ai.com. We respond to all privacy-related inquiries within 72 hours.`,
  },
];

export function Privacy() {
  return (
    <div className="py-24 max-w-4xl mx-auto px-6">
      <Reveal>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-teal-light border border-teal/20 flex items-center justify-center">
            <Shield className="w-6 h-6 text-teal" />
          </div>
          <div>
            <h1 className="font-display text-4xl">Privacy Policy</h1>
            <p className="text-xs font-mono text-muted mt-1">Last updated: March 2026</p>
          </div>
        </div>
        <p className="text-muted leading-relaxed mb-12 max-w-2xl">
          LECTRA-AI is built by students, for students. We take your privacy seriously. This policy explains exactly what data we collect, how we use it, and what rights you have over it.
        </p>
      </Reveal>

      <div className="space-y-0 border-t border-border">
        {SECTIONS.map((s, i) => (
          <Reveal key={s.title} delay={i * 40}>
            <div className="py-8 border-b border-border grid md:grid-cols-[200px_1fr] gap-6">
              <h3 className="font-bold text-sm">{s.title}</h3>
              <p className="text-muted text-sm leading-relaxed">{s.content}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
