import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Clock, ChevronDown, Lightbulb, Loader2 } from 'lucide-react';

type Msg = { role: 'user' | 'ai'; text: string; ts?: string; citations?: string[]; lang?: string; };

const INITIAL: Msg[] = [
  {
    role: 'ai',
    text: 'Hi! I\'m ready to answer questions about "Machine Learning — Lecture 5: Neural Networks". You can ask in English, Urdu, or Roman Urdu.',
    ts: '09:00',
  },
];

const SUGGESTIONS = [
  'What topics were covered in this lecture?',
  'Explain gradient descent in simple terms.',
  'What did the teacher emphasize most?',
  'Generate 3 quiz questions from this lecture.',
];

const LECTURES = [
  'Machine Learning — Lecture 5: Neural Networks',
  'Database Systems — Normalization',
  'Data Structures — AVL Trees',
];

// Simulate AI responses
const AI_RESPONSES: { trigger: string; text: string; citations?: string[]; }[] = [
  { trigger: 'gradient', text: 'Gradient descent is an optimization algorithm used to minimize a loss function. The key parameters are:\n\n• **Learning rate (α)**: controls step size — too high = overshoot, too low = slow convergence.\n• **Gradient**: the direction of steepest ascent — we move *against* it.\n\nIn code: `w = w - α × ∇L(w)`', citations: ['14:32', '22:18'] },
  { trigger: 'topic', text: 'This lecture covered the following key topics:\n\n1. Neural network architecture (input, hidden, output layers)\n2. Forward propagation and activation functions\n3. The loss function and why we minimize it\n4. Gradient descent and learning rate tuning\n5. Backpropagation using the chain rule\n\nThe teacher spent the most time on gradient descent and backpropagation.', citations: ['02:15', '45:00'] },
  { trigger: 'quiz', text: 'Here are 3 quiz questions based on this lecture:\n\n**Q1.** What happens if the learning rate is set too high in gradient descent?\n\n**Q2.** In backpropagation, which mathematical rule is used to compute gradients layer by layer?\n\n**Q3.** What is the vanishing gradient problem, and which activation function helps mitigate it?\n\nWould you like me to quiz you interactively?' },
  { trigger: 'urdu|roman|samajh|batao', text: 'Bilkul! Neural network ek system hai jo insaan ke dimagh ki tarah kaam karta hai.\n\nIsmein teen hissay hote hain:\n• **Input layer** — data leta hai\n• **Hidden layers** — data process karta hai\n• **Output layer** — result deta hai\n\nHar layer mein "neurons" hote hain jo data ko aage bhejte hain.' },
];

function getAIReply(userMsg: string): Msg {
  const lower = userMsg.toLowerCase();
  const match = AI_RESPONSES.find(r => new RegExp(r.trigger).test(lower));
  const now = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  if (match) return { role: 'ai', text: match.text, citations: match.citations, ts: now };
  return {
    role: 'ai',
    text: `That's a great question about the lecture. Based on the transcript, this topic was discussed in detail. The key insight is that understanding the underlying mechanism — not just memorizing formulas — is what leads to real comprehension.\n\nWould you like me to explain it in Urdu or Roman Urdu?`,
    ts: now,
    citations: ['08:45'],
  };
}

function renderText(text: string) {
  const lines = text.split('\n');
  return lines.map((line, i) => {
    const formatted = line.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`(.+?)`/g, '<code class="font-mono text-xs bg-surface px-1 py-0.5 rounded">$1</code>');
    return <p key={i} className={`${line.startsWith('•') || line.startsWith('•') ? 'pl-2' : ''} ${i > 0 && line === '' ? 'mt-2' : 'mt-0.5'} leading-relaxed`} dangerouslySetInnerHTML={{ __html: formatted }} />;
  });
}

export function Chat() {
  const [msgs, setMsgs] = useState<Msg[]>(INITIAL);
  const [input, setInput] = useState('');
  const [lang, setLang] = useState<'English' | 'Urdu' | 'Roman Urdu'>('English');
  const [lecture, setLecture] = useState(LECTURES[0]);
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [msgs, typing]);

  const send = (text: string = input.trim()) => {
    if (!text) return;
    const now = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    setMsgs(prev => [...prev, { role: 'user', text, ts: now, lang }]);
    setInput('');
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs(prev => [...prev, getAIReply(text)]);
    }, 1200 + Math.random() * 800);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-7rem)] py-4 page-enter">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 shrink-0">
        <div>
          <h1 className="font-display text-2xl mb-0.5">Ask Your Lecture</h1>
          <p className="text-xs text-muted font-mono">Powered by RAG · context-aware answers</p>
        </div>
        <div className="relative">
          <select
            value={lecture}
            onChange={e => { setLecture(e.target.value); setMsgs(INITIAL); }}
            className="appearance-none flex items-center gap-2 pl-4 pr-10 py-2 rounded-xl bg-surface border border-border text-sm font-medium hover:bg-surface2 transition-colors outline-none focus:border-accent cursor-pointer"
          >
            {LECTURES.map(l => <option key={l} value={l}>{l.length > 35 ? l.slice(0, 35) + '…' : l}</option>)}
          </select>
          <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted pointer-events-none" />
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 bg-surface border border-border rounded-2xl overflow-hidden flex flex-col shadow-sm min-h-0">
        <div className="flex-1 p-5 overflow-y-auto space-y-5">
          {msgs.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${m.role === 'ai' ? 'bg-accent-light' : 'bg-teal-light'}`}>
                {m.role === 'ai' ? <Bot className="w-4 h-4 text-accent" /> : <User className="w-4 h-4 text-teal" />}
              </div>
              <div className={`max-w-[78%] ${m.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                <div className={`px-4 py-3 rounded-2xl text-sm ${m.role === 'ai' ? 'bg-surface2 rounded-tl-none' : 'bg-accent text-white rounded-tr-none'}`}>
                  {m.role === 'ai' ? <div className="space-y-0.5">{renderText(m.text)}</div> : <p className="leading-relaxed">{m.text}</p>}
                  {m.citations && m.citations.length > 0 && (
                    <div className="flex items-center gap-2 mt-3 pt-2 border-t border-border">
                      <span className="text-[10px] font-mono text-muted uppercase tracking-widest">Source:</span>
                      {m.citations.map(c => (
                        <button key={c} className="flex items-center gap-1 px-2 py-0.5 rounded bg-surface border border-border text-[10px] font-medium hover:border-accent2 transition-colors">
                          <Clock className="w-2.5 h-2.5 text-accent" /> {c}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <span className="text-[10px] font-mono text-muted px-1">{m.ts}</span>
              </div>
            </div>
          ))}

          {typing && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-accent-light flex items-center justify-center shrink-0"><Bot className="w-4 h-4 text-accent" /></div>
              <div className="bg-surface2 rounded-2xl rounded-tl-none px-4 py-3 flex items-center gap-1.5">
                <Loader2 className="w-3.5 h-3.5 text-muted animate-spin" />
                <span className="text-sm text-muted">Thinking...</span>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Suggestions */}
        {msgs.length <= 1 && (
          <div className="px-5 pb-3 shrink-0">
            <div className="flex items-center gap-2 mb-2">
              <Lightbulb className="w-3.5 h-3.5 text-amber" />
              <span className="text-[10px] font-mono text-muted uppercase tracking-widest">Suggested questions</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {SUGGESTIONS.map(s => (
                <button key={s} onClick={() => send(s)}
                  className="text-xs px-3 py-1.5 bg-surface border border-border rounded-full hover:border-accent2 hover:text-accent transition-colors">
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 bg-surface border-t border-border shrink-0">
          <div className="relative">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
              placeholder={`Ask in ${lang}…`}
              className="w-full pl-4 pr-12 py-3 rounded-xl border border-border bg-bg focus:border-accent outline-none text-sm transition-colors"
            />
            <button onClick={() => send()} disabled={!input.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg bg-accent text-white flex items-center justify-center hover:bg-accent2 transition-colors disabled:opacity-40 disabled:cursor-not-allowed">
              <Send className="w-3.5 h-3.5 ml-0.5" />
            </button>
          </div>
          <div className="flex items-center justify-between mt-2 px-1">
            <span className="text-[10px] font-mono text-muted uppercase tracking-widest">Press Enter to send</span>
            <div className="flex gap-3">
              {(['English', 'Urdu', 'Roman Urdu'] as const).map(l => (
                <button key={l} onClick={() => setLang(l)}
                  className={`text-[10px] font-mono uppercase tracking-widest transition-colors ${lang === l ? 'text-accent font-bold' : 'text-muted hover:text-text'}`}>
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
