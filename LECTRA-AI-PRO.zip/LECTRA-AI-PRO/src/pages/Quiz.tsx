import React from 'react';
import { useState, useEffect } from 'react';
import { CheckCircle2, XCircle, Clock, ChevronRight, ChevronLeft, RotateCcw, Trophy, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

type Phase = 'setup' | 'quiz' | 'results';

const QUESTIONS = [
  {
    q: 'What is the primary purpose of the learning rate in gradient descent?',
    options: [
      'To determine the number of iterations needed to converge.',
      'To control the size of the steps taken towards the minimum of the loss function.',
      'To calculate the derivative of the loss function with respect to the weights.',
      'To initialize the weights of the model before training begins.',
    ],
    correct: 1,
    topic: 'Gradient Descent',
    explanation: 'The learning rate scales the gradient step — too high and you overshoot the minimum, too low and convergence is painfully slow.',
  },
  {
    q: 'In a neural network, what does backpropagation compute?',
    options: [
      'The forward pass activations layer by layer.',
      'The optimal learning rate for each layer automatically.',
      'The gradient of the loss with respect to each weight using the chain rule.',
      'The number of neurons needed per hidden layer.',
    ],
    correct: 2,
    topic: 'Backpropagation',
    explanation: 'Backpropagation applies the chain rule of calculus to propagate the loss gradient backward through all layers, enabling weight updates.',
  },
  {
    q: 'Which activation function is most commonly used in hidden layers of modern deep networks?',
    options: ['Sigmoid', 'Tanh', 'ReLU', 'Softmax'],
    correct: 2,
    topic: 'Activation Functions',
    explanation: 'ReLU (Rectified Linear Unit) is dominant in hidden layers because it avoids the vanishing gradient problem that plagues Sigmoid and Tanh.',
  },
  {
    q: 'What does "overfitting" mean in machine learning?',
    options: [
      'The model trains too slowly due to insufficient data.',
      'The model learns the training data too well, including noise, and fails to generalize.',
      'The model has too few parameters to capture the underlying pattern.',
      'The loss function reaches zero during training.',
    ],
    correct: 1,
    topic: 'Generalization',
    explanation: 'Overfitting happens when a model memorizes training data details rather than learning the underlying pattern — it performs great on training data but poorly on new examples.',
  },
  {
    q: 'What is the vanishing gradient problem?',
    options: [
      'Gradients become very large and cause weight updates to explode.',
      'The loss function becomes stuck in a local minimum.',
      'Gradients become extremely small in early layers, making those weights nearly impossible to train.',
      'The model fails to converge due to a poorly chosen optimizer.',
    ],
    correct: 2,
    topic: 'Deep Networks',
    explanation: 'In deep networks with Sigmoid or Tanh, gradients shrink as they propagate back through many layers — the earliest layers learn almost nothing. ReLU and residual connections help mitigate this.',
  },
];

function ConfettiPiece({ x, color }: { x: number; color: string; [k: string]: unknown }) {
  const dur = 1.0 + Math.random() * 0.8;
  const delay = Math.random() * 0.6;
  return (
    <div className="absolute top-0 w-2 h-2 rounded-sm confetti pointer-events-none"
      style={{ left: `${x}%`, background: color, '--dur': `${dur}s`, '--delay': `${delay}s` } as React.CSSProperties}
    />
  );
}

const CONFETTI_COLORS = ['#1a5c8f','#0e8a6e','#b8730a','#6b3fa0','#c0392b','#2878b5'];
const CONFETTI = Array.from({ length: 40 }, (_, i) => ({ x: (i / 40) * 100 + Math.random() * 5, color: CONFETTI_COLORS[i % CONFETTI_COLORS.length] }));

export function Quiz() {
  const [phase, setPhase] = useState<Phase>('setup');
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>(Array(QUESTIONS.length).fill(null));
  const [selected, setSelected] = useState<number | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [timed, setTimed] = useState(true);
  const [timeLeft, setTimeLeft] = useState(30);
  const [showConf, setShowConf] = useState(false);

  const q = QUESTIONS[current];
  const score = answers.filter((a, i) => a === QUESTIONS[i].correct).length;
  const pct = Math.round((score / QUESTIONS.length) * 100);

  useEffect(() => {
    if (phase !== 'quiz' || !timed || revealed) return;
    if (timeLeft <= 0) { handleReveal(); return; }
    const t = setTimeout(() => setTimeLeft(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [phase, timed, timeLeft, revealed]);

  const handleSelect = (i: number) => { if (!revealed) setSelected(i); };
  const handleReveal = () => {
    if (selected !== null) {
      setAnswers(prev => { const next = [...prev]; next[current] = selected; return next; });
    }
    setRevealed(true);
  };
  const handleNext = () => {
    if (current < QUESTIONS.length - 1) {
      setCurrent(c => c + 1); setSelected(null); setRevealed(false); setTimeLeft(30);
    } else {
      setPhase('results');
      if (pct >= 75) setTimeout(() => setShowConf(true), 200);
    }
  };

  if (phase === 'setup') {
    return (
      <div className="py-8 page-enter max-w-2xl mx-auto">
        <h1 className="font-display text-3xl mb-2">Quiz & Assessment</h1>
        <p className="text-muted mb-8">Configure and start your quiz session.</p>
        <div className="bg-surface border border-border rounded-2xl p-8 space-y-6">
          <div>
            <label className="block text-sm font-bold mb-3">Lecture</label>
            <select className="w-full bg-bg border border-border rounded-xl px-4 py-3 text-sm outline-none focus:border-accent transition-colors">
              <option>Machine Learning — Lecture 5: Neural Networks</option>
              <option>Database Systems — Normalization</option>
              <option>Data Structures — AVL Trees</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-bold mb-3">Difficulty</label>
            <div className="flex gap-3">
              {['Beginner','Intermediate','Advanced'].map((d, i) => (
                <button key={d} className={`flex-1 py-2.5 rounded-xl border text-sm font-medium transition-colors ${i === 1 ? 'bg-accent text-white border-accent' : 'bg-surface2 border-border'}`}>{d}</button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-bold mb-3">Number of questions</label>
            <div className="flex gap-3">
              {[5, 10, 20].map(n => (
                <button key={n} className={`flex-1 py-2.5 rounded-xl border text-sm font-medium transition-colors ${n === 5 ? 'bg-accent text-white border-accent' : 'bg-surface2 border-border'}`}>{n}</button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between py-3 border-t border-border">
            <div>
              <div className="text-sm font-bold">Timed mode</div>
              <div className="text-xs text-muted">30 seconds per question</div>
            </div>
            <button onClick={() => setTimed(!timed)}
              className={`w-12 h-6 rounded-full transition-colors relative ${timed ? 'bg-accent' : 'bg-border2'}`}>
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${timed ? 'translate-x-7' : 'translate-x-1'}`} />
            </button>
          </div>
          <button onClick={() => { setPhase('quiz'); setCurrent(0); setAnswers(Array(QUESTIONS.length).fill(null)); setSelected(null); setRevealed(false); setTimeLeft(30); }}
            className="w-full bg-accent hover:bg-accent2 text-white py-4 rounded-xl font-bold transition-all hover:-translate-y-0.5 shadow-sm">
            Start Quiz ({QUESTIONS.length} Questions)
          </button>
        </div>
      </div>
    );
  }

  if (phase === 'results') {
    const byTopic = QUESTIONS.reduce<Record<string, { correct: number; total: number }>>((acc, q, i) => {
      if (!acc[q.topic]) acc[q.topic] = { correct: 0, total: 0 };
      acc[q.topic].total++;
      if (answers[i] === q.correct) acc[q.topic].correct++;
      return acc;
    }, {});

    return (
      <div className="py-8 page-enter max-w-2xl mx-auto relative">
        {showConf && (
          <div className="fixed inset-x-0 top-0 pointer-events-none overflow-hidden z-50 h-40">
            {CONFETTI.map((c, i) => <ConfettiPiece key={i} {...c} />)}
          </div>
        )}

        <div className="text-center mb-8">
          <div className="w-28 h-28 mx-auto mb-6 relative">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="44" fill="none" stroke="var(--color-border)" strokeWidth="8" />
              <circle cx="50" cy="50" r="44" fill="none" strokeWidth="8" strokeLinecap="round"
                className={`ring-fill ${pct >= 80 ? 'stroke-teal' : pct >= 60 ? 'stroke-amber' : 'stroke-red'}`}
                strokeDasharray={`${pct * 2.76} 276`} />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="font-display text-3xl">{pct}%</span>
              <span className="text-xs text-muted font-mono">{score}/{QUESTIONS.length}</span>
            </div>
          </div>
          <h2 className="font-display text-3xl mb-2">{pct >= 80 ? '🎉 Excellent!' : pct >= 60 ? '👍 Good job!' : '📚 Keep studying'}</h2>
          <p className="text-muted">{pct >= 80 ? 'You have a strong grasp of this material.' : pct >= 60 ? 'A few topics need more attention.' : 'Review the weak topics below and try again.'}</p>
        </div>

        <div className="bg-surface border border-border rounded-2xl p-6 mb-6">
          <h3 className="font-bold mb-4 flex items-center gap-2"><Trophy className="w-4 h-4 text-amber" /> Topic Breakdown</h3>
          <div className="space-y-4">
            {Object.entries(byTopic).map(([topic, { correct, total }]) => {
              const p = Math.round((correct / total) * 100);
              return (
                <div key={topic}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span>{topic}</span>
                    <span className={`font-mono font-medium ${p >= 80 ? 'text-teal' : p >= 60 ? 'text-amber' : 'text-red'}`}>{p}%</span>
                  </div>
                  <div className="w-full bg-border rounded-full h-2">
                    <div className={`h-2 rounded-full transition-all ${p >= 80 ? 'bg-teal' : p >= 60 ? 'bg-amber' : 'bg-red'}`} style={{ width: `${p}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button onClick={() => { setPhase('setup'); setShowConf(false); }}
            className="flex-1 flex items-center justify-center gap-2 py-3 border border-border rounded-xl text-sm font-medium hover:bg-surface2 transition-colors">
            <RotateCcw className="w-4 h-4" /> Try Again
          </button>
          <Link to="/app/analytics" className="flex-1 flex items-center justify-center gap-2 py-3 border border-border rounded-xl text-sm font-medium hover:bg-surface2 transition-colors">
            <BookOpen className="w-4 h-4" /> View Analytics
          </Link>
          <Link to="/app/chat" className="flex-1 flex items-center justify-center gap-2 py-3 bg-accent text-white rounded-xl text-sm font-bold hover:bg-accent2 transition-colors">
            Ask AI About Weak Topics
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 page-enter max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          {QUESTIONS.map((_, i) => (
            <div key={i} className={`w-2.5 h-2.5 rounded-full transition-colors ${i < current ? 'bg-teal' : i === current ? 'bg-accent' : 'bg-border2'}`} />
          ))}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-mono text-muted">Q {current + 1} / {QUESTIONS.length}</span>
          {timed && (
            <div className={`flex items-center gap-1.5 text-sm font-mono font-bold px-3 py-1.5 rounded-lg transition-colors ${timeLeft <= 10 ? 'bg-red-light text-red' : 'bg-surface2 text-muted'}`}>
              <Clock className="w-3.5 h-3.5" />{timeLeft}s
            </div>
          )}
        </div>
      </div>

      {timed && (
        <div className="w-full bg-border rounded-full h-1.5 mb-6 overflow-hidden">
          <div className="h-full bg-accent transition-all duration-1000" style={{ width: `${(timeLeft / 30) * 100}%` }} />
        </div>
      )}

      <div className="bg-surface border border-border rounded-2xl p-8 mb-4">
        <div className="inline-flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest bg-accent-light text-accent px-2.5 py-1 rounded-full mb-5 border border-accent/20">{q.topic}</div>
        <p className="text-lg font-medium mb-7 leading-relaxed">{q.q}</p>
        <div className="space-y-3">
          {q.options.map((opt, i) => {
            let cls = 'border-border bg-surface hover:border-accent2';
            if (revealed) {
              if (i === q.correct) cls = 'border-teal bg-teal-light/40';
              else if (i === selected && i !== q.correct) cls = 'border-red bg-red-light/40';
              else cls = 'border-border bg-surface opacity-50';
            } else if (selected === i) {
              cls = 'border-accent bg-accent-light/40';
            }
            return (
              <button key={i} onClick={() => handleSelect(i)}
                className={`w-full flex items-start gap-4 p-4 rounded-xl border text-left text-sm transition-all ${cls} ${!revealed ? 'cursor-pointer' : 'cursor-default'}`}>
                <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold transition-colors ${selected === i && !revealed ? 'bg-accent border-accent text-white' : revealed && i === q.correct ? 'bg-teal border-teal text-white' : revealed && i === selected ? 'bg-red border-red text-white' : 'border-border2'}`}>
                  {revealed && i === q.correct ? <CheckCircle2 className="w-3 h-3" /> : revealed && i === selected && i !== q.correct ? <XCircle className="w-3 h-3" /> : String.fromCharCode(65 + i)}
                </div>
                <span className="leading-relaxed">{opt}</span>
              </button>
            );
          })}
        </div>

        {revealed && (
          <div className="mt-5 p-4 bg-surface2 rounded-xl border border-border">
            <div className="text-xs font-mono text-accent uppercase tracking-widest mb-1.5">Explanation</div>
            <p className="text-sm text-muted leading-relaxed">{q.explanation}</p>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between">
        <button disabled={current === 0} onClick={() => { setCurrent(c => c - 1); setSelected(answers[current - 1]); setRevealed(answers[current - 1] !== null); setTimeLeft(30); }}
          className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-muted hover:text-text disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
          <ChevronLeft className="w-4 h-4" /> Previous
        </button>
        {!revealed ? (
          <button onClick={handleReveal} disabled={selected === null}
            className="bg-accent hover:bg-accent2 disabled:opacity-40 disabled:cursor-not-allowed text-white px-8 py-2.5 rounded-xl text-sm font-bold transition-all hover:-translate-y-0.5">
            Check Answer
          </button>
        ) : (
          <button onClick={handleNext}
            className="flex items-center gap-2 bg-accent hover:bg-accent2 text-white px-8 py-2.5 rounded-xl text-sm font-bold transition-all hover:-translate-y-0.5">
            {current < QUESTIONS.length - 1 ? 'Next Question' : 'See Results'} <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
