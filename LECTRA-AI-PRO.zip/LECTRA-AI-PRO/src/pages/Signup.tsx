import React, { useState, MouseEvent } from 'react';
import { Mail, Lock, User, ArrowRight, Eye, EyeOff, GraduationCap, BookOpen } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '../components/ToastProvider';

const UNIS = ['NUCES (FAST)', 'NUST', 'LUMS', 'IBA Karachi', 'UET Lahore', 'COMSATS', 'Air University', 'Other'];

function strengthLabel(pw: string): { label: string; color: string; width: string } {
  if (!pw) return { label: '', color: 'bg-border', width: '0%' };
  const score = [pw.length >= 8, /[A-Z]/.test(pw), /[0-9]/.test(pw), /[^A-Za-z0-9]/.test(pw)].filter(Boolean).length;
  if (score <= 1) return { label: 'Weak', color: 'bg-red', width: '25%' };
  if (score === 2) return { label: 'Fair', color: 'bg-amber', width: '50%' };
  if (score === 3) return { label: 'Good', color: 'bg-accent2', width: '75%' };
  return { label: 'Strong', color: 'bg-teal', width: '100%' };
}

export function Signup() {
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [uni, setUni] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { toast } = useToast();
  const navigate = useNavigate();
  const strength = strengthLabel(password);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setRotation({
      x: ((e.clientY - rect.top - rect.height / 2) / rect.height) * -3,
      y: ((e.clientX - rect.left - rect.width / 2) / rect.width) * 3,
    });
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = 'Full name is required';
    if (!email) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = 'Enter a valid email address';
    if (!password) errs.password = 'Password is required';
    else if (password.length < 8) errs.password = 'Password must be at least 8 characters';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1400));
    setLoading(false);
    toast('success', 'Account created! Welcome to LECTRA-AI.');
    navigate('/app/dashboard');
  };

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center relative overflow-hidden py-12" style={{ perspective: '1000px' }}>
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-[20%] right-[20%] w-96 h-96 bg-accent/10 rounded-full filter blur-[100px] animate-pulse" />
        <div className="absolute bottom-[20%] left-[20%] w-[500px] h-[500px] bg-purple/10 rounded-full filter blur-[120px] animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="w-full max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center z-10">
        {/* Card */}
        <div style={{ perspective: '1000px' }}>
          <div
            onMouseMove={handleMouseMove}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => { setRotation({ x: 0, y: 0 }); setIsHovered(false); }}
            className="w-full max-w-md mx-auto transition-transform duration-200 ease-out"
            style={{ transform: isHovered ? `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) translateZ(20px)` : 'none', transformStyle: 'preserve-3d' }}
          >
            <div className="bg-surface/80 backdrop-blur-xl border border-border p-10 rounded-3xl shadow-2xl">
              <div className="mb-7 text-center">
                <h2 className="text-3xl font-bold mb-2">Create Account</h2>
                <p className="text-muted text-sm">Join LECTRA-AI and transform how you study</p>
              </div>

              <form className="space-y-4" onSubmit={handleSubmit} noValidate>
                <div>
                  <label className="text-sm font-medium text-muted block mb-1.5 ml-1">Full Name</label>
                  <div className="relative group">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted group-focus-within:text-accent transition-colors" />
                    <input type="text" value={name} onChange={e => { setName(e.target.value); setErrors(p => ({ ...p, name: '' })); }}
                      className={`w-full bg-bg border rounded-xl py-3 pl-11 pr-4 text-sm placeholder:text-muted/50 focus:border-accent outline-none transition-colors ${errors.name ? 'border-red' : 'border-border'}`}
                      placeholder="Hassan Raza" />
                  </div>
                  {errors.name && <p className="text-xs text-red mt-1 ml-1">{errors.name}</p>}
                </div>

                <div>
                  <label className="text-sm font-medium text-muted block mb-1.5 ml-1">Email Address</label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted group-focus-within:text-accent transition-colors" />
                    <input type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors(p => ({ ...p, email: '' })); }}
                      className={`w-full bg-bg border rounded-xl py-3 pl-11 pr-4 text-sm placeholder:text-muted/50 focus:border-accent outline-none transition-colors ${errors.email ? 'border-red' : 'border-border'}`}
                      placeholder="hassan@nuces.edu.pk" />
                  </div>
                  {errors.email && <p className="text-xs text-red mt-1 ml-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="text-sm font-medium text-muted block mb-1.5 ml-1">Password</label>
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted group-focus-within:text-accent transition-colors" />
                    <input type={showPw ? 'text' : 'password'} value={password} onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: '' })); }}
                      className={`w-full bg-bg border rounded-xl py-3 pl-11 pr-11 text-sm placeholder:text-muted/50 focus:border-accent outline-none transition-colors ${errors.password ? 'border-red' : 'border-border'}`}
                      placeholder="At least 8 characters" />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted hover:text-text">
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {password && (
                    <div className="mt-2 ml-1">
                      <div className="w-full bg-border rounded-full h-1.5 overflow-hidden">
                        <div className={`${strength.color} h-1.5 rounded-full transition-all duration-400`} style={{ width: strength.width }} />
                      </div>
                      <p className="text-[10px] mt-1 text-muted">Password strength: <span className="font-bold">{strength.label}</span></p>
                    </div>
                  )}
                  {errors.password && <p className="text-xs text-red mt-1 ml-1">{errors.password}</p>}
                </div>

                <div>
                  <label className="text-sm font-medium text-muted block mb-1.5 ml-1">University <span className="text-muted/50">(optional)</span></label>
                  <div className="relative">
                    <BookOpen className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted pointer-events-none" />
                    <select value={uni} onChange={e => setUni(e.target.value)}
                      className="w-full bg-bg border border-border rounded-xl py-3 pl-11 pr-4 text-sm focus:border-accent outline-none transition-colors appearance-none">
                      <option value="">Select your university</option>
                      {UNIS.map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                  </div>
                </div>

                <button type="submit" disabled={loading}
                  className="w-full mt-3 bg-accent hover:bg-accent2 disabled:opacity-70 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all hover:-translate-y-0.5">
                  {loading ? (
                    <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Creating account…</>
                  ) : (
                    <><span>Create Account</span><ArrowRight className="w-4 h-4" /></>
                  )}
                </button>

                <p className="text-center text-sm text-muted mt-3">
                  Already have an account?{' '}
                  <Link to="/login" className="font-bold text-accent hover:text-accent2 transition-colors">Sign in</Link>
                </p>
              </form>
            </div>
          </div>
        </div>

        {/* Branding */}
        <div className="hidden md:flex flex-col gap-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-accent2" />
            </div>
            <span className="font-display text-2xl font-bold">LECTRA-AI</span>
          </div>
          <h1 className="text-5xl lg:text-6xl font-display font-bold leading-tight">
            Never miss<br />a detail<br />
            <span className="text-accent2">again.</span>
          </h1>
          <p className="text-lg text-muted max-w-md leading-relaxed">Create your free account and get full access to AI transcription, smart quizzes, and noise-free audio perfectly tailored to your lectures.</p>
          <div className="space-y-3 mt-2">
            {['Free to start — no credit card', 'Urdu & Roman Urdu explanations', 'Your data is always private'].map(f => (
              <div key={f} className="flex items-center gap-3 text-sm text-muted">
                <div className="w-5 h-5 rounded-full bg-teal-light border border-teal/20 flex items-center justify-center shrink-0">
                  <div className="w-2 h-2 rounded-full bg-teal" />
                </div>
                {f}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
