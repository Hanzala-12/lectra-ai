import React, { useState, MouseEvent } from 'react';
import { Mail, Lock, ArrowRight, Eye, EyeOff, GraduationCap } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useToast } from '../components/ToastProvider';

export function Login() {
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const rotateX = ((e.clientY - rect.top - rect.height / 2) / rect.height) * -5;
    const rotateY = ((e.clientX - rect.left - rect.width / 2) / rect.width) * 5;
    setRotation({ x: rotateX, y: rotateY });
  };

  const validate = () => {
    const errs: typeof errors = {};
    if (!email) errs.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(email)) errs.email = 'Enter a valid email address';
    if (!password) errs.password = 'Password is required';
    else if (password.length < 6) errs.password = 'Password must be at least 6 characters';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 1200));
    setLoading(false);
    toast('success', 'Welcome back, Hassan!');
    navigate('/app/dashboard');
  };

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center relative overflow-hidden" style={{ perspective: '1000px' }}>
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-[20%] left-[20%] w-96 h-96 bg-accent/10 rounded-full filter blur-[100px] animate-pulse" />
        <div className="absolute bottom-[20%] right-[20%] w-[500px] h-[500px] bg-accent2/10 rounded-full filter blur-[120px] animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      <div className="w-full max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center z-10">
        {/* Left: branding */}
        <div className="hidden md:flex flex-col gap-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-accent2" />
            </div>
            <span className="font-display text-2xl font-bold">LECTRA-AI</span>
          </div>
          <h1 className="text-5xl lg:text-6xl font-display font-bold leading-tight">
            Unlock your<br />
            <span className="text-accent2">Brilliance.</span>
          </h1>
          <p className="text-lg text-muted max-w-md leading-relaxed">Join LECTRA-AI to instantly transcribe, analyze, and learn from any lecture. Your ultimate AI study companion awaits.</p>
          <div className="flex items-center gap-4 mt-4">
            <div className="flex -space-x-3">
              {['HR','MH','MZ','AK'].map((i) => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-bg bg-surface2 flex items-center justify-center text-[10px] font-bold">{i}</div>
              ))}
            </div>
            <span className="text-sm text-muted">+4,200 students using LECTRA-AI</span>
          </div>
        </div>

        {/* Right: 3D card */}
        <div style={{ perspective: '1000px' }}>
          <div
            onMouseMove={handleMouseMove}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => { setRotation({ x: 0, y: 0 }); setIsHovered(false); }}
            className="w-full max-w-md mx-auto transition-transform duration-200 ease-out"
            style={{
              transform: isHovered ? `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) translateZ(20px)` : 'none',
              transformStyle: 'preserve-3d',
            }}
          >
            <div className="bg-surface/80 backdrop-blur-xl border border-border p-10 rounded-3xl shadow-2xl">
              <div className="mb-8 text-center">
                <h2 className="text-3xl font-bold mb-2">Welcome Back</h2>
                <p className="text-muted text-sm">Enter your details to access your dashboard</p>
              </div>

              <form className="space-y-5" onSubmit={handleSubmit} noValidate>
                <div>
                  <label className="text-sm font-medium text-muted block mb-1.5 ml-1">Email Address</label>
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted group-focus-within:text-accent transition-colors" />
                    <input type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors(p => ({ ...p, email: undefined })); }}
                      className={`w-full bg-bg border rounded-xl py-3.5 pl-11 pr-4 text-sm placeholder:text-muted/50 focus:border-accent outline-none transition-colors ${errors.email ? 'border-red' : 'border-border'}`}
                      placeholder="hanzala@nuces.edu.pk" />
                  </div>
                  {errors.email && <p className="text-xs text-red mt-1 ml-1">{errors.email}</p>}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5 ml-1">
                    <label className="text-sm font-medium text-muted">Password</label>
                    <Link to="#" className="text-xs text-accent hover:text-accent2 transition-colors">Forgot?</Link>
                  </div>
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted group-focus-within:text-accent transition-colors" />
                    <input type={showPw ? 'text' : 'password'} value={password} onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: undefined })); }}
                      className={`w-full bg-bg border rounded-xl py-3.5 pl-11 pr-11 text-sm placeholder:text-muted/50 focus:border-accent outline-none transition-colors ${errors.password ? 'border-red' : 'border-border'}`}
                      placeholder="••••••••" />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted hover:text-text transition-colors">
                      {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errors.password && <p className="text-xs text-red mt-1 ml-1">{errors.password}</p>}
                </div>

                <div className="flex items-center gap-2 ml-1">
                  <input type="checkbox" id="remember" className="w-4 h-4 rounded accent-accent" />
                  <label htmlFor="remember" className="text-sm text-muted">Remember me</label>
                </div>

                <button type="submit" disabled={loading}
                  className="w-full mt-2 bg-accent hover:bg-accent2 disabled:opacity-70 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 transition-all hover:-translate-y-0.5">
                  {loading ? (
                    <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Signing in…</>
                  ) : (
                    <><span>Sign In</span><ArrowRight className="w-4 h-4" /></>
                  )}
                </button>

                <p className="text-center text-sm text-muted mt-4">
                  Don't have an account?{' '}
                  <Link to="/signup" className="font-bold text-accent hover:text-accent2 transition-colors">Sign up free</Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
