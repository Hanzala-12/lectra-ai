import { Link } from 'react-router-dom';
import { UploadCloud, TrendingUp, AlertTriangle, CheckCircle2, Clock, BookOpen, Brain, ArrowRight } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const STATS = [
  { label: 'Lectures', value: '12', sub: '+3 this week', color: 'text-accent2' },
  { label: 'Avg Quiz Score', value: '84%', sub: '↑ 6% from last week', color: 'text-teal' },
  { label: 'Hours Saved', value: '18h', sub: 'vs manual note-taking', color: 'text-amber' },
  { label: 'Weak Topics', value: '3', sub: 'need review today', color: 'text-red' },
];

const RECENT = [
  { title: 'Machine Learning — Lecture 5: Neural Networks', course: 'CS401', date: 'Oct 15', dur: '1h 12m', speakers: 4, badge: 'DONE', badgeColor: 'bg-teal-light text-teal border-teal/20' },
  { title: 'Database Systems — Normalization & 3NF', course: 'CS311', date: 'Oct 13', dur: '58m', speakers: 2, badge: 'QUIZ DUE', badgeColor: 'bg-amber-light text-amber border-amber/20' },
  { title: 'Data Structures — AVL Trees', course: 'CS201', date: 'Oct 11', dur: '1h 5m', speakers: 2, badge: 'DONE', badgeColor: 'bg-teal-light text-teal border-teal/20' },
];

const WEAK = [
  { topic: 'Gradient Descent', score: 42, color: 'bg-red' },
  { topic: 'Backpropagation', score: 55, color: 'bg-amber' },
  { topic: 'SQL Joins', score: 58, color: 'bg-amber' },
];

const PLAN = [
  { done: true, task: 'Review Lecture 4 transcript' },
  { done: false, task: 'Quiz: Gradient Descent (10 Qs)' },
  { done: false, task: 'Upload Lecture 6' },
  { done: false, task: 'AI Chat: clarify AVL rotations' },
];

const COURSES = ['CS401','CS311','CS201','CS101'];

export function Dashboard() {
  return (
    <div className="py-8 page-enter">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl mb-1">Good morning, Hassan 👋</h1>
          <p className="text-muted text-sm">You have 2 unreviewed lectures and a quiz due today.</p>
        </div>
        <Link to="/app/upload" className="hidden sm:flex items-center gap-2 bg-accent hover:bg-accent2 text-white px-5 py-2.5 rounded-xl text-sm font-bold transition-all shadow-sm hover:-translate-y-0.5">
          <UploadCloud className="w-4 h-4" /> Upload Lecture
        </Link>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 60}>
            <div className="bg-surface border border-border rounded-xl p-5">
              <div className="text-xs font-mono text-muted uppercase tracking-widest mb-2">{s.label}</div>
              <div className={`font-display text-3xl mb-1 ${s.color}`}>{s.value}</div>
              <div className="text-xs text-muted">{s.sub}</div>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Recent lectures */}
        <div className="md:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-lg">Recent Lectures</h2>
            <Link to="/app/library" className="text-xs font-mono text-accent hover:underline">View all →</Link>
          </div>
          <div className="space-y-3">
            {RECENT.map((r, i) => (
              <Reveal key={r.title} delay={i * 80}>
                <div className="bg-surface border border-border rounded-xl p-4 card-lift flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-accent-light flex items-center justify-center text-xs font-bold text-accent shrink-0">{r.course.slice(0, 2)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate mb-1">{r.title}</div>
                    <div className="text-xs text-muted font-mono">{r.course} · {r.date} · {r.dur} · {r.speakers} speakers</div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-[10px] font-mono px-2 py-1 rounded border ${r.badgeColor}`}>{r.badge}</span>
                    <Link to="/app/library" className="text-xs text-muted hover:text-accent transition-colors"><ArrowRight className="w-4 h-4" /></Link>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {/* Weekly activity */}
          <div className="mt-6">
            <h2 className="font-bold text-lg mb-4">Weekly Activity</h2>
            <div className="bg-surface border border-border rounded-xl p-5">
              <div className="flex items-end gap-2 h-24">
                {[2, 0, 3, 1, 4, 2, 1].map((count, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1">
                    <div className="w-full rounded-t-md transition-all" style={{ height: `${Math.max(8, count * 22)}px`, background: count > 0 ? 'var(--color-accent)' : 'var(--color-border2)', opacity: count > 0 ? 0.7 + count * 0.1 : 1 }} />
                    <div className="text-[9px] font-mono text-muted">{['M','T','W','T','F','S','S'][i]}</div>
                  </div>
                ))}
              </div>
              <div className="text-xs text-muted mt-3 font-mono">13 lectures studied this week · 6-day streak 🔥</div>
            </div>
          </div>
        </div>

        {/* Right column */}
        <div className="flex flex-col gap-5">
          {/* Weak topics */}
          <div className="bg-red-light border border-red/20 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-red" />
              <h3 className="font-bold text-red text-sm">Weak Topics</h3>
            </div>
            <p className="text-xs text-red/70 mb-4">You scored below 60% on these topics.</p>
            <div className="space-y-3">
              {WEAK.map(({ topic, score, color }) => (
                <div key={topic}>
                  <div className="flex justify-between text-xs mb-1"><span className="font-medium">{topic}</span><span className="font-mono text-muted">{score}%</span></div>
                  <div className="w-full bg-surface rounded-full h-1.5"><div className={`${color} h-1.5 rounded-full transition-all`} style={{ width: `${score}%` }} /></div>
                </div>
              ))}
            </div>
            <Link to="/app/quiz" className="mt-4 w-full block text-center py-2 bg-red text-white rounded-lg text-xs font-bold hover:opacity-90 transition-opacity">Generate Review Quiz →</Link>
          </div>

          {/* Today's study plan */}
          <div className="bg-surface border border-border rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle2 className="w-4 h-4 text-teal" />
              <h3 className="font-bold text-sm">Today's Study Plan</h3>
            </div>
            <div className="space-y-3">
              {PLAN.map(({ done, task }) => (
                <div key={task} className="flex items-center gap-3">
                  <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${done ? 'bg-teal border-teal' : 'border-border2'}`}>
                    {done && <CheckCircle2 className="w-3 h-3 text-white" />}
                  </div>
                  <span className={`text-xs ${done ? 'line-through text-muted' : ''}`}>{task}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Courses */}
          <div className="bg-surface border border-border rounded-xl p-5">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-4 h-4 text-accent" />
              <h3 className="font-bold text-sm">Your Courses</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {COURSES.map(c => (
                <span key={c} className="text-xs font-mono bg-accent-light text-accent px-3 py-1.5 rounded-full border border-accent/20">{c}</span>
              ))}
            </div>
            <Link to="/app/library" className="mt-4 flex items-center gap-1 text-xs text-muted hover:text-accent transition-colors">
              <Brain className="w-3.5 h-3.5" /> Browse lecture library →
            </Link>
          </div>

          {/* Quick upload */}
          <div className="bg-accent-light border border-accent/20 rounded-xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-accent" />
              <h3 className="font-bold text-sm text-accent">Quick Tip</h3>
            </div>
            <p className="text-xs text-accent/80 mb-3 leading-relaxed">Upload your next lecture right after class while it's fresh. Processing takes just 2–5 minutes.</p>
            <Link to="/app/upload" className="flex items-center gap-1 text-xs font-bold text-accent hover:underline">
              <Clock className="w-3 h-3" /> Upload now →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
