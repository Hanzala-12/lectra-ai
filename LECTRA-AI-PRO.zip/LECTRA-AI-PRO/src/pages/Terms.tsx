import { FileText } from 'lucide-react';
import { Reveal } from '../components/Reveal';

const SECTIONS = [
  { title: 'Acceptable use', content: 'You may use LECTRA-AI to process lectures, educational content, and study materials that you have the right to upload. You may not upload copyrighted audio or video that you do not own or have permission to use. You may not use the platform for any illegal purpose.' },
  { title: 'Academic integrity', content: 'LECTRA-AI is designed to aid learning, not to enable academic dishonesty. Using AI-generated explanations or quiz answers to misrepresent your own knowledge in graded academic work may violate your institution\'s academic integrity policy. You are responsible for how you use the outputs of this platform.' },
  { title: 'Account responsibility', content: 'You are responsible for maintaining the security of your account credentials. Do not share your account with others. You are responsible for all activity that occurs under your account.' },
  { title: 'Processing limits', content: 'Free accounts may process up to 5 lectures per month. Uploaded files may not exceed 500MB. Audio duration may not exceed 3 hours per file. We reserve the right to adjust these limits.' },
  { title: 'Service availability', content: 'We aim for 99% uptime but do not guarantee uninterrupted service. Scheduled maintenance will be announced in advance where possible. We are not liable for losses caused by service downtime.' },
  { title: 'Intellectual property', content: 'LECTRA-AI and its underlying technology are the intellectual property of the NUCES CFD 2026 project team. You retain full ownership of all content you upload. AI-generated transcripts, explanations, and quiz questions derived from your content are provided to you for your personal educational use.' },
  { title: 'Limitation of liability', content: 'LECTRA-AI is provided "as is" for educational purposes. We do not guarantee the accuracy of transcriptions or AI explanations. Transcription accuracy may vary by audio quality, accent, and background noise. Do not rely solely on LECTRA-AI outputs for critical academic or professional decisions.' },
  { title: 'Changes to terms', content: 'We may update these terms from time to time. Significant changes will be communicated via email to registered users. Continued use of the platform after updates constitutes acceptance of the new terms.' },
];

export function Terms() {
  return (
    <div className="py-24 max-w-4xl mx-auto px-6">
      <Reveal>
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-accent-light border border-accent/20 flex items-center justify-center">
            <FileText className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h1 className="font-display text-4xl">Terms of Service</h1>
            <p className="text-xs font-mono text-muted mt-1">Last updated: March 2026</p>
          </div>
        </div>
        <p className="text-muted leading-relaxed mb-12 max-w-2xl">
          By using LECTRA-AI, you agree to these terms. Please read them carefully. They're written plainly — no legal jargon.
        </p>
      </Reveal>

      <div className="space-y-0 border-t border-border">
        {SECTIONS.map((s, i) => (
          <Reveal key={s.title} delay={i * 40}>
            <div className="py-8 border-b border-border grid md:grid-cols-[200px_1fr] gap-6">
              <h3 className="font-bold text-sm">{s.title}</h3>
              <p className="text-muted text-sm leading-relaxed">{s.content}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  );
}
