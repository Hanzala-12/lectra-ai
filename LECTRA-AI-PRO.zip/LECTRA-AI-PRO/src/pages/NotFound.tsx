import { Link } from 'react-router-dom';
import { useEffect, useRef } from 'react';
import { UploadCloud } from 'lucide-react';

export function NotFound() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    let frame = 0, raf: number;
    const resize = () => { canvas.width = canvas.offsetWidth * window.devicePixelRatio; canvas.height = canvas.offsetHeight * window.devicePixelRatio; ctx.scale(window.devicePixelRatio, window.devicePixelRatio); };
    resize(); window.addEventListener('resize', resize);
    const draw = () => {
      const w = canvas.offsetWidth, h = canvas.offsetHeight;
      ctx.clearRect(0, 0, w, h);
      const bars = 40, barW = w / bars;
      for (let i = 0; i < bars; i++) {
        const t = frame * 0.02 + i * 0.4;
        const amp = Math.sin(t) * 0.35 + Math.sin(t * 1.8) * 0.25;
        const bh = Math.max(2, Math.abs(amp) * h * 0.6);
        ctx.fillStyle = `rgba(26,92,143,${0.08 + Math.abs(amp) * 0.2})`;
        ctx.beginPath(); ctx.roundRect(i * barW + 1, (h - bh) / 2, barW - 2, bh, 2); ctx.fill();
      }
      frame++; raf = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center text-center px-6 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <canvas ref={canvasRef} className="w-full h-full opacity-40" />
      </div>
      <div className="relative z-10">
        <div className="font-display text-[8rem] leading-none text-border2 mb-2 select-none">404</div>
        <h1 className="font-display text-3xl mb-4">Lecture not found</h1>
        <p className="text-muted mb-2 max-w-md">Looks like this page got lost in the noise reduction stage.</p>
        <p className="text-sm text-muted/60 font-mono mb-10">The URL you tried doesn't exist — or it got processed out of existence.</p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/" className="flex items-center gap-2 bg-accent hover:bg-accent2 text-white px-6 py-3 rounded-xl font-bold transition-all hover:-translate-y-0.5">
            Go Home
          </Link>
          <Link to="/app/upload" className="flex items-center gap-2 border border-border px-6 py-3 rounded-xl font-medium hover:bg-surface2 transition-colors">
            <UploadCloud className="w-4 h-4" /> Upload a Lecture
          </Link>
        </div>
      </div>
    </div>
  );
}
